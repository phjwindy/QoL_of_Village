﻿# install_qol.ps1 — Village in the Shade QoL MOD 整合包一键安装器
# 用法：把游戏目录（或 village.exe）拖到 install.bat 上，或在游戏目录里直接双击 install.bat
# 功能：
#   1) 幂等安装基座：原版 steam_api64.dll 自动改名备份为 steam_api64_org.dll（已有则跳过）
#   2) 旧版本 MOD 自动让位：Mods\ 内同前缀旧版本文件夹移入游戏根 待用MOD\（防双加载）
#   3) 复制 MODS\ 全部 MOD 到 <游戏>\Mods\
#   4) 校验游戏本体大小与 MOD 清单是否匹配（不匹配仅警告，不阻断）
# 回滚：删除游戏根目录 steam_api64.dll，把 steam_api64_org.dll 改名回 steam_api64.dll
param([string]$TargetDir = "")

$ErrorActionPreference = 'Stop'
$BundleRoot = $PSScriptRoot

function Write-Msg([string]$m) { Write-Host $m }
function Write-Ok([string]$m)  { Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn2([string]$m){ Write-Host "  [WARN] $m" -ForegroundColor Yellow }
function Write-Err2([string]$m){ Write-Host "  [ERR] $m" -ForegroundColor Red }

# ---------- 定位游戏目录 ----------
function Find-GameDir {
    # 1) Steam 注册表 + libraryfolders.vdf
    try {
        $steam = (Get-ItemProperty 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        $libs = @($steam)
        if (Test-Path $vdf) {
            foreach ($line in Get-Content $vdf) {
                if ($line -match '"\d+"\s+"([^"]+)"') {
                    $p = $Matches[1] -replace '\\\\', '\'
                    if ($p -and (Test-Path $p)) { $libs += $p }
                }
            }
        }
        foreach ($lib in $libs) {
            $cand = Join-Path $lib 'steamapps\common\Village in the Shade'
            if (Test-Path (Join-Path $cand 'village.exe')) { return $cand }
        }
    } catch { }
    return $null
}

$gameDir = $null
if ($TargetDir) {
    # 支持拖入 village.exe 或游戏目录
    if (Test-Path $TargetDir -PathType Leaf) { $TargetDir = Split-Path $TargetDir -Parent }
    if (Test-Path (Join-Path $TargetDir 'village.exe')) { $gameDir = $TargetDir }
    else { Write-Err2 "指定目录没有 village.exe：$TargetDir" }
}
if (-not $gameDir) {
    $gameDir = Find-GameDir
    if ($gameDir) { Write-Ok "自动定位游戏目录：$gameDir" }
}
if (-not $gameDir) {
    Write-Msg ""
    Write-Msg "未自动找到游戏目录，请输入游戏安装目录（含 village.exe 的文件夹），回车跳过退出："
    $inp = Read-Host "游戏目录"
    if ($inp -and (Test-Path (Join-Path $inp.Trim('"') 'village.exe'))) {
        $gameDir = $inp.Trim('"')
    } else {
        Write-Err2 "未找到有效游戏目录，退出。"
        exit 1
    }
}

# ---------- 前置检查 ----------
$bundleBase = Join-Path $BundleRoot 'steam_api64.dll'
$bundleMods = Join-Path $BundleRoot 'MODS'
if (-not (Test-Path $bundleBase)) { Write-Err2 "整合包缺少 steam_api64.dll（基座本体）"; exit 1 }
if (-not (Test-Path $bundleMods)) { Write-Err2 "整合包缺少 MODS 文件夹"; exit 1 }

Write-Msg ""
Write-Msg "===== QoL MOD 一键安装 ====="
Write-Msg "游戏目录：$gameDir"
Write-Msg ""

# ---------- 1. 基座安装（幂等） ----------
$orgPath = Join-Path $gameDir 'steam_api64_org.dll'
$curBase = Join-Path $gameDir 'steam_api64.dll'
if (Test-Path $orgPath) {
    Write-Ok "基座已安装过（steam_api64_org.dll 存在），更新基座本体"
} elseif (Test-Path $curBase) {
    $same = $false
    try {
        $h1 = (Get-FileHash $curBase -Algorithm SHA256).Hash
        $h2 = (Get-FileHash $bundleBase -Algorithm SHA256).Hash
        $same = ($h1 -eq $h2)
    } catch { }
    if ($same) {
        Write-Ok "当前 steam_api64.dll 就是本基座（哈希一致），无需改名"
    } else {
        Rename-Item $curBase 'steam_api64_org.dll'
        Write-Ok "原版 steam_api64.dll 已备份为 steam_api64_org.dll"
    }
} else {
    Write-Err2 "游戏根目录没有 steam_api64.dll —— 请确认这是 Steam 正版游戏目录"
    exit 1
}
Copy-Item $bundleBase $curBase -Force
Write-Ok "基座 steam_api64.dll 已就位"

# ---------- 2. 旧版本 MOD 让位（防双加载） ----------
$modsDst = Join-Path $gameDir 'Mods'
New-Item -ItemType Directory -Path $modsDst -Force | Out-Null
$storage = Join-Path $gameDir '待用MOD'
New-Item -ItemType Directory -Path $storage -Force | Out-Null

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$existing = @(Get-ChildItem $modsDst -Directory -ErrorAction SilentlyContinue)
foreach ($bundleMod in (Get-ChildItem $bundleMods -Directory)) {
    # 前缀 = 文件夹名去掉 "_v<数字..." 后缀（MOD 名本身不含 _v 数字）
    $prefix = $bundleMod.Name -replace '_v[\d\.]+.*$', ''
    foreach ($old in $existing) {
        if ($old.Name -eq $bundleMod.Name) { continue }        # 同版本稍后覆盖
        if ($old.Name -notlike "$prefix*") { continue }        # 不同 MOD
        $dest = Join-Path $storage $old.Name
        if (Test-Path $dest) { $dest = Join-Path $storage "$($old.Name)_old_$stamp" }
        Move-Item $old.FullName $dest
        Write-Ok "旧版本让位：Mods\$($old.Name) → 待用MOD\$(Split-Path $dest -Leaf)"
    }
}

# ---------- 3. 复制 MOD ----------
$n = 0
foreach ($bundleMod in (Get-ChildItem $bundleMods -Directory)) {
    $dst = Join-Path $modsDst $bundleMod.Name
    New-Item -ItemType Directory -Path $dst -Force | Out-Null
    Copy-Item (Join-Path $bundleMod.FullName '*') $dst -Force
    $n++
    Write-Ok "已安装 Mods\$($bundleMod.Name)"
}

# ---------- 4. 游戏版本校验（警告级） ----------
$exe = Join-Path $gameDir 'village.exe'
$oneInfo = Get-ChildItem $bundleMods -Directory |
    ForEach-Object { Join-Path $_.FullName 'modinfo.txt' } |
    Where-Object { Test-Path $_ } | Select-Object -First 1
if ($oneInfo -and (Test-Path $exe)) {
    $size = $null
    foreach ($line in Get-Content $oneInfo) {
        if ($line -match '^game_size=(\d+)$') { $size = [long]$Matches[1]; break }
    }
    if ($size -and $size -ne (Get-Item $exe).Length) {
        Write-Warn2 "游戏本体大小与 MOD 清单不一致（清单=$size 实际=$((Get-Item $exe).Length)）"
        Write-Warn2 "游戏可能不是本 MOD 适配的版本（v1.30 build 25640656），部分 MOD 会自动安全停用"
    } elseif ($size) {
        Write-Ok "游戏本体大小与 MOD 清单一致（v1.30 build 25640656）"
    }
}

Write-Msg ""
Write-Ok "===== 安装完成：共 $n 个 MOD ====="
Write-Msg "  直接从 Steam 启动游戏即可，不需要启动器或启动项。"
Write-Msg "  游戏内按 F9 打开 MOD 管理面板。"
Write-Msg "  回滚：删除游戏根目录 steam_api64.dll，把 steam_api64_org.dll 改名回 steam_api64.dll。"
