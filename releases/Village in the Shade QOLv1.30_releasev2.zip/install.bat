@echo off
rem install.bat - QoL MOD bundle one-click installer
rem Usage: double-click (auto-find game dir), or drag village.exe / game folder onto this file.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_qol.ps1" %*
echo.
pause
